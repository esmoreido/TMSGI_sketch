# AmperkaTDS
Arduino library to interface with the TDS sensor.
